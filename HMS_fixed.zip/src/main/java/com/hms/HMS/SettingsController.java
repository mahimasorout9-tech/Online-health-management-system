package com.hms.HMS;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SettingsController {

    private final SettingsService settingsService;

    public SettingsController(SettingsService settingsService) {
        this.settingsService = settingsService;
    }

    @GetMapping("/settings")
    public String settings(Model model) {
        Settings settings = settingsService.getSettings();

        if (settings != null) {
            model.addAttribute("settings", settings);
        } else {
            model.addAttribute("settings", new Settings());
        }

        return "settings";
    }

    @PostMapping("/settings/update")
    public String updateSettings(Settings settings) {
        settingsService.saveSettings(settings);
        return "redirect:/settings";
    }
}