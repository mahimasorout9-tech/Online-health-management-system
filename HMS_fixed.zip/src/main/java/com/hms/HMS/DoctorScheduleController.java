package com.hms.HMS;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DoctorScheduleController {

    private final DoctorScheduleService doctorScheduleService;

    public DoctorScheduleController(DoctorScheduleService doctorScheduleService) {
        this.doctorScheduleService = doctorScheduleService;
    }

    @GetMapping("/doctor/schedule")
    public String schedulePage(HttpSession session, Model model) {
        String email = (String) session.getAttribute("userEmail");
        model.addAttribute("schedule", new DoctorSchedule());
        model.addAttribute("doctorEmail", email);
        model.addAttribute("schedules", doctorScheduleService.getSchedulesByDoctorEmail(email));
        return "doctor-schedule";
    }

    @PostMapping("/doctor/schedule")
    public String saveSchedule(@ModelAttribute DoctorSchedule schedule, HttpSession session) {
        schedule.setId(null);
        schedule.setDoctorEmail((String) session.getAttribute("userEmail"));
        doctorScheduleService.saveSchedule(schedule);
        return "redirect:/doctor/schedule";
    }

    @GetMapping("/doctor/schedule/delete/{id}")
    public String deleteSchedule(@PathVariable Long id, HttpSession session) {
        DoctorSchedule s = doctorScheduleService.getScheduleById(id);
        String email = (String) session.getAttribute("userEmail");
        // a doctor may only delete their own schedule entries
        if (s != null && email != null && email.equals(s.getDoctorEmail())) {
            doctorScheduleService.deleteSchedule(id);
        }
        return "redirect:/doctor/schedule";
    }
}
