package com.hms.HMS;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MedicalRecordController {

    private final MedicalRecordService medicalRecordService;

    public MedicalRecordController(MedicalRecordService medicalRecordService) {
        this.medicalRecordService = medicalRecordService;
    }

    @GetMapping("/doctor/medical-record")
    public String medicalRecordForm(HttpSession session, Model model) {
        model.addAttribute("doctorName", session.getAttribute("userName"));
        return "medical-record";
    }

    @PostMapping("/doctor/medical-record")
    public String saveMedicalRecord(@ModelAttribute MedicalRecord record, HttpSession session) {
        record.setId(null);
        record.setDoctor((String) session.getAttribute("userName"));
        medicalRecordService.saveMedicalRecord(record);
        return "redirect:/doctor/medical-record";
    }
}
