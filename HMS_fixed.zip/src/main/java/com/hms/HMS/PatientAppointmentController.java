package com.hms.HMS;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PatientAppointmentController {

    private final AppointmentService appointmentService;

    public PatientAppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @GetMapping("/patient/appointments")
    public String patientAppointments(HttpSession session, Model model) {
        String name = (String) session.getAttribute("userName");
        model.addAttribute("patientName", name);
        model.addAttribute("appointments", appointmentService.getAppointmentsByPatientName(name));
        return "patient-appointments";
    }

    @PostMapping("/patient/appointments")
    public String bookAppointment(@ModelAttribute Appointment appointment, HttpSession session) {
        // Never trust identity/status from the form
        appointment.setId(null);
        appointment.setPatientName((String) session.getAttribute("userName"));
        appointment.setStatus("Pending");
        appointmentService.saveAppointment(appointment);
        return "redirect:/patient/appointments";
    }
}
