package com.hms.HMS;

import org.springframework.stereotype.Service;

@Service
public class SettingsService {

    private final SettingsRepository settingsRepository;

    public SettingsService(SettingsRepository settingsRepository) {
        this.settingsRepository = settingsRepository;
    }

    public Settings saveSettings(Settings settings) {
        return settingsRepository.save(settings);
    }

    public Settings getSettings() {
        return settingsRepository.findAll()
                .stream()
                .findFirst()
                .orElse(null);
    }
}
