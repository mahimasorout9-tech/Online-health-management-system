package com.hms.HMS;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "users";
    }

    // Admin creates a user (any role)
    @PostMapping("/users")
    public String createUser(@ModelAttribute User user, Model model) {

        if (userService.getUserByEmail(user.getEmail()) != null) {
            model.addAttribute("error", "This email is already registered.");
            model.addAttribute("users", userService.getAllUsers());
            return "users";
        }

        user.setId(null);
        userService.saveUser(user);
        return "redirect:/users";
    }

    @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return "redirect:/users";
    }

    @GetMapping("/users/edit/{id}")
    public String editUser(@PathVariable Long id, Model model) {
        User user = userService.getUserById(id);
        if (user == null) {
            return "redirect:/users";
        }
        model.addAttribute("user", user);
        return "edit-user";
    }

    // FIX: the edit form has no password field, so saving the bound User
    // used to overwrite the stored password with null. Load the existing
    // user and change only name/email/role.
    @PostMapping("/users/update")
    public String updateUser(@ModelAttribute User form, Model model) {
        User existing = userService.getUserById(form.getId());
        if (existing == null) {
            return "redirect:/users";
        }

        User sameEmail = userService.getUserByEmail(form.getEmail());
        if (sameEmail != null && !sameEmail.getId().equals(existing.getId())) {
            model.addAttribute("error", "This email is already used by another user.");
            model.addAttribute("user", existing);
            return "edit-user";
        }

        existing.setName(form.getName());
        existing.setEmail(form.getEmail());
        existing.setRole(form.getRole());
        userService.saveUser(existing);
        return "redirect:/users";
    }

    // Public self-registration: only Patient or Doctor allowed
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, Model model) {

        if (userService.getUserByEmail(user.getEmail()) != null) {
            model.addAttribute("error",
                    "This email is already registered. Please use another email.");
            return "register";
        }

        String role = user.getRole();
        if (!"Doctor".equalsIgnoreCase(role)) {
            role = "Patient";   // blocks someone tampering the form to become Admin
        } else {
            role = "Doctor";
        }
        user.setRole(role);
        user.setId(null);

        userService.saveUser(user);
        return "redirect:/login";
    }
}
