package com.hms.HMS;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    private final UserService userService;

    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String loginPage(Model model) {
        model.addAttribute("error", "");
        return "login";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String password,
            HttpServletRequest request,
            Model model) {

        User user = userService.getUserByEmail(email);

        if (user == null) {
            model.addAttribute("error", "Email is not registered.");
            return "login";
        }

        // password may be null for accounts damaged by the old edit-user bug
        if (user.getPassword() == null || !user.getPassword().equals(password)) {
            model.addAttribute("error", "Wrong password.");
            return "login";
        }

        String role = user.getRole() == null ? "" : user.getRole();
        if (!role.equalsIgnoreCase("Patient")
                && !role.equalsIgnoreCase("Doctor")
                && !role.equalsIgnoreCase("Admin")) {
            model.addAttribute("error", "Invalid user role.");
            return "login";
        }

        // Remember who is logged in
        request.getSession(true);
        request.changeSessionId();
        HttpSession session = request.getSession();
        session.setAttribute("userId", user.getId());
        session.setAttribute("userName", user.getName());
        session.setAttribute("userEmail", user.getEmail());
        session.setAttribute("userRole", role);

        if (role.equalsIgnoreCase("Patient")) {
            return "redirect:/patient";
        }
        if (role.equalsIgnoreCase("Doctor")) {
            return "redirect:/doctor";
        }
        return "redirect:/admin";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }
}
