package com.hms.HMS;

import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DoctorScheduleService {

    private final DoctorScheduleRepository doctorScheduleRepository;

    public DoctorScheduleService(DoctorScheduleRepository doctorScheduleRepository) {
        this.doctorScheduleRepository = doctorScheduleRepository;
    }

    public DoctorSchedule saveSchedule(DoctorSchedule schedule) {
        return doctorScheduleRepository.save(schedule);
    }

    public List<DoctorSchedule> getSchedulesByDoctorEmail(String doctorEmail) {
        return doctorScheduleRepository.findByDoctorEmail(doctorEmail);
    }

    public DoctorSchedule getScheduleById(Long id) {
        return doctorScheduleRepository.findById(id).orElse(null);
    }

    public void deleteSchedule(Long id) {
        doctorScheduleRepository.deleteById(id);
    }
}
