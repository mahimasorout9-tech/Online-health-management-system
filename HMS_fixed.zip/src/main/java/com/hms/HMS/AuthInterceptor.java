package com.hms.HMS;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;

/** Blocks pages unless the right role is logged in. */
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        HttpSession session = request.getSession(false);
        String role = (session == null) ? null : (String) session.getAttribute("userRole");

        if (role == null) {
            response.sendRedirect("/login");
            return false;
        }

        String path = request.getRequestURI();
        boolean allowed;

        if (path.startsWith("/doctor")) {
            allowed = role.equalsIgnoreCase("Doctor");
        } else if (path.startsWith("/patient")) {
            allowed = role.equalsIgnoreCase("Patient");
        } else {
            // /admin, /users, /settings, /performance, /appointments
            allowed = role.equalsIgnoreCase("Admin");
        }

        if (!allowed) {
            response.sendRedirect("/login");
            return false;
        }
        return true;
    }
}
