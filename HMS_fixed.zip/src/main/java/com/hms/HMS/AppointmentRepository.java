package com.hms.HMS;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    long countByStatus(String status);

    List<Appointment> findByPatientName(String patientName);

    List<Appointment> findByDoctorName(String doctorName);
}
