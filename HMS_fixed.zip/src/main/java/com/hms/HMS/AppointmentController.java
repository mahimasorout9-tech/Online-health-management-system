package com.hms.HMS;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class AppointmentController {

    private final AppointmentService appointmentService;

    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @GetMapping("/appointments")
    public String appointments(Model model) {

        model.addAttribute("appointment", new Appointment());
        model.addAttribute("appointments", appointmentService.getAllAppointments());

        return "appointment";
    }

    @PostMapping("/appointments")
    public String saveAppointment(@ModelAttribute Appointment appointment) {

        appointment.setId(null);

        appointmentService.saveAppointment(appointment);

        return "redirect:/appointments";
    }

    @GetMapping("/doctor/appointments")
    public String doctorAppointments(HttpSession session, Model model) {

        String doctorName = (String) session.getAttribute("userName");
        model.addAttribute("appointments", appointmentService.getAppointmentsByDoctorName(doctorName));

        return "doctor-appointments";
    }
}