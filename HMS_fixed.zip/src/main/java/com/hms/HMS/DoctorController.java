package com.hms.HMS;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DoctorController {

    private final UserService userService;

    public DoctorController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/doctor")
    public String doctor() {
        return "doctor";
    }

    // Was returning "patient" (the patient dashboard). Now shows the patient list.
    @GetMapping("/doctor/patients")
    public String doctorPatients(Model model) {
        model.addAttribute("patients", userService.getUsersByRole("Patient"));
        return "doctor-patients";
    }
}
