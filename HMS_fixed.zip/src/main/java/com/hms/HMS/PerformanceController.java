package com.hms.HMS;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PerformanceController {

    private final AppointmentRepository appointmentRepository;
    private final UserRepository userRepository;

    public PerformanceController(
            AppointmentRepository appointmentRepository,
            UserRepository userRepository) {

        this.appointmentRepository = appointmentRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/performance")
    public String performance(Model model) {

        long totalAppointments = appointmentRepository.count();
        long completedAppointments = appointmentRepository.countByStatus("Completed");
        long totalUsers = userRepository.count();
        long totalDoctors = userRepository.countByRole("Doctor");
        long totalPatients = userRepository.countByRole("Patient");

        model.addAttribute("totalAppointments", totalAppointments);
        model.addAttribute("completedAppointments", completedAppointments);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalDoctors", totalDoctors);
        model.addAttribute("totalPatients", totalPatients);

        return "performance";
    }
}