package com.hms.HMS;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    long countByRole(String role);

    User findByEmail(String email);

    List<User> findByRole(String role);
}
