package com.hms.HMS;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PatientController {

    private final MedicalRecordService medicalRecordService;

    public PatientController(MedicalRecordService medicalRecordService) {
        this.medicalRecordService = medicalRecordService;
    }

    @GetMapping("/patient")
    public String patient() {
        return "patient";
    }

    @GetMapping("/patient/medical-history")
    public String medicalHistory(HttpSession session, Model model) {
        String email = (String) session.getAttribute("userEmail");
        model.addAttribute("records", medicalRecordService.getRecordsByPatientEmail(email));
        return "medical-history";
    }
}
